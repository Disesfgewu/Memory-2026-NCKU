#include "lab1_read_write_student.hh"

#include <algorithm>
#include <unordered_map>
#include <vector>

#include "ftl/page_mapping.hh"
#include "util/algorithm.hh"

namespace SSDLab {

namespace FTL {

void Lab1ReadWriteStudent::readInternal(PageMapping &ftl, Request &req,
                                        uint64_t &tick) {
  PAL::Request palRequest(req);
  uint64_t beginAt;
  uint64_t finishedAt = tick;

  auto mappingList = ftl.table.find(req.lpn);

  // An unmapped LPN does not issue a NAND read.
  if (mappingList == ftl.table.end()) {
    return;
  }

  // Mapping-table access latency
  ftl.pDRAM->read(&(*mappingList), 8, tick);

  // TODO: Read Implementation

  tick = finishedAt;
  tick += applyLatency(CPU::FTL__PAGE_MAPPING, CPU::READ_INTERNAL);
}


void Lab1ReadWriteStudent::writeInternal(PageMapping &ftl, Request &req,
                                         uint64_t &tick) {
  PAL::Request palRequest(req);
  uint64_t beginAt;
  uint64_t finishedAt = tick;

  auto mappingList = ftl.table.find(req.lpn);

  // TODO: Write Implementation - Write Path
  


  /*
   * Mapping-table access latency.
   * This timing model is provided and should not be modified.
   */
  ftl.pDRAM->read(&(*mappingList), 8, tick);
  ftl.pDRAM->write(&(*mappingList), 8, tick);

  // TODO: Write Implementation - Physical Write


  tick = finishedAt;
  tick += applyLatency(CPU::FTL__PAGE_MAPPING, CPU::WRITE_INTERNAL);

  // The GC-related code should not be modified.
  static float gcThreshold =
      ftl.conf.readFloat(CONFIG_FTL, FTL_GC_THRESHOLD_RATIO);

  if (ftl.freeBlockRatio() < gcThreshold) {
    ftl.handleOnDemandGC(tick);
  }
}

}  // namespace FTL

}  // namespace SSDLab
